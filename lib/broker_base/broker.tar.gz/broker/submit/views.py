from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render
from django.http import HttpResponse,HttpResponseBadRequest, HttpResponseNotFound
from django.template.response import TemplateResponse

def status(request):
    import socket
    try:
        HOSTNAME = socket.gethostname()
    except:
        HOSTNAME = 'localhost'
    import json
    response_data = {
        'hostname': HOSTNAME
    }
    return HttpResponse(json.dumps(response_data), content_type="application/json")

@csrf_exempt
def push(request):
    try:
        try:
            filename  = str(request.FILES['file'])
        except KeyError:
            filename = request.POST['file_name']
            fileid   = request.POST['file_id']
        container = request.POST['container']
    except KeyError as e:
        return HttpResponseBadRequest("container name needed")
    from .models import Files
    try:
        trigger = request.POST['type']
        from celery_app import push_data,retry_policy,queue_push_req,push_data
        from uuid import uuid4
        file_id = str(uuid4())
        file_obj = Files(file_id=file_id, file=request.FILES['file'], file_name=filename)
        file_obj.save()
        push_data.apply_async((container, filename, file_id), retry=True, retry_policy=retry_policy)
    except KeyError:
        try:
            file_obj = Files.objects.get(file_id=fileid)
        except Files.DoesNotExist:
            return HttpResponseNotFound("File id:'%s' not found or already served" % filename)
        filename = filename.encode('utf-8', 'ignore')
        file = open("/data/%s" % filename, "wb")
        file.write(file_obj.file.read())
        file.close()
        file_obj.delete()
    return HttpResponse("ok")

def upload(request):
    response = TemplateResponse(request, 'upload_page.html', {})
    return response
