import requests
import json
import httplib2, urllib
import traceback
from base64 import b64decode
from uuid import uuid4
from xml.etree import ElementTree

from django.template import RequestContext
from django.core.urlresolvers import reverse
from django.http import Http404, HttpResponse, HttpResponseRedirect, HttpResponseNotFound, HttpResponseBadRequest, HttpResponseServerError, HttpResponseForbidden
from django.conf import settings
from django.shortcuts import redirect, render_to_response
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth import login
from django.shortcuts import resolve_url

from oauth2client.django_orm import Storage
from oauth2client.client import Credentials

from apiclient.discovery import build
import apiclient.errors
from oauth2client.client import OAuth2WebServerFlow, OAuth2Credentials

def is_authenticated(request):
    if not getattr(settings, 'EMAIL_ENFORCED'):
        return HttpResponse("Authentication not enforced")
        
    if request.user.is_authenticated():
        return HttpResponse(json.dumps({'user': str(request.user)}))
    return HttpResponseForbidden()

def get_redirect_uri(request):
    try:
        http_host   = request.META['HTTP_X_FORWARDED_FOR']
        http_scheme = request.META['wsgi.url_scheme']
        redirect_uri = "%s://%s%s" % (http_scheme, http_host, reverse('authentication:google_authenticate_redirect'))
    except KeyError:
        redirect_uri = request.build_absolute_uri(reverse('authentication:google_authenticate_redirect'))
    return redirect_uri

def get_redirect_host(request):
    try:
        http_host   = request.META['HTTP_X_FORWARDED_FOR']
        http_scheme = request.META['wsgi.url_scheme']
        redirect_uri = "%s://%s" % (http_scheme, http_host)
    except KeyError:
        redirect_uri = "/"
    return redirect_uri

def authenticate_with_google(request):
    client_id = getattr(settings, 'GOOGLE_CLIENT_ID', None)
    client_secret = getattr(settings, 'GOOGLE_CLIENT_SECRET', None)
    if not client_id:
        return HttpResponseBadRequest("GOOGLE Oauth2 not setup, missing api keys in settings")

    redirect_uri = get_redirect_uri(request)

    # Force session recreation on each authentication request, to allow user to re-login with different google account
    request.session.create()
    session_state = request.session.session_key

    payload = {'client_id': client_id, 'response_type': 'code', 
        'scope': 'openid profile email https://www.googleapis.com/auth/plus.login', 
        'redirect_uri': redirect_uri, 'state': session_state}
    r = requests.get('https://accounts.google.com/o/oauth2/auth', params=payload, allow_redirects=False)
    
    if r.status_code == 302 and 'location' in r.headers:
        return redirect(r.headers['location'])
    return HttpResponseServerError("Failed to send request, please try again later")

def google_authenticate_redirect(request):
    if not request.GET.get('state') or request.GET['state'] != request.session.session_key:        
        return HttpResponse(content=json.dumps('Invalid state parameter.'), content_type='application/json', status=401)
 
    redirect_uri = get_redirect_uri(request)

    client_id = getattr(settings, 'GOOGLE_CLIENT_ID', None)
    client_secret = getattr(settings, 'GOOGLE_CLIENT_SECRET', None)
    payload = {'client_id': client_id, 'client_secret': client_secret, 'code': request.GET['code'], 
        'redirect_uri': redirect_uri, 'grant_type': 'authorization_code'}
    r = requests.post("https://accounts.google.com/o/oauth2/token", data=payload)
    if r.status_code != 200:
        return HttpResponse("Could not authenticate")
    tokens = json.loads(r.text)

    id_tokens = tokens['id_token'].split('.')
    if (len(id_tokens) != 3): 
        return HttpResponse("Could not authenticate")
    b64_string = id_tokens[1]
    b64_string += "=" * ((4 - len(b64_string) % 4) % 4)
    user_info = json.loads(b64decode(b64_string))

    email_req = getattr(settings, 'EMAIL_ENFORCED')
    if user_info['email'] != email_req:
        return HttpResponse("Expecting different email")
    try:
        user = User.objects.get(email=user_info['email'])
        user.backend = 'django.contrib.auth.backends.ModelBackend'
        login(request, user)
        return redirect(get_redirect_host(request))
    except User.DoesNotExist:
        credentials = OAuth2Credentials(access_token=tokens['access_token'], client_id=client_id, client_secret=client_secret, 
                token_expiry=tokens['expires_in'], token_uri=redirect_uri, user_agent='NeweraHPC Web-Server', 
                refresh_token=None, id_token=tokens['id_token'])
        http = httplib2.Http()
        http = credentials.authorize(http)

        SERVICE = build('plus', 'v1')
        try:
            google_request = SERVICE.people().get(userId='me')
            result = google_request.execute(http=http)
        except apiclient.errors.HttpError as e:
            return HttpResponse("Error: Please contact the administrator<br> %s" % e._get_reason())
        except:
            return HttpResponse("Communication with the identity provider failed, kindly retry after sometime")

        fname = ""
        lname = ""
        if 'name' in result:
            if 'givenName' in result['name']:
                fname = result['name']['givenName']
            if 'familyName' in result['name']:
                lname = result['name']['familyName']

        username = str(uuid4())
        new_user = User.objects.create_user(username=username, email=user_info['email'], first_name=fname, last_name=lname)
        new_user.is_active = True
        new_user.set_unusable_password()
        new_user.save()
        new_user.backend = 'django.contrib.auth.backends.ModelBackend'
        login(request, new_user)
        return redirect(get_redirect_host(request))
